from flask import Flask, render_template, request
import joblib
import numpy as np
from flask import Flask, render_template, request, url_for
from facedetection import facedetection_bp 
from flask import Flask, render_template, Blueprint
from introvert import introvert_bp
from introvert import introvert_questions
from flask import Flask, jsonify


app = Flask(__name__)


# Load the trained model
model = joblib.load(r"C:\Users\Hi\OneDrive\Desktop\rnsit\8th sem\projects\final year project\depression moule.sav\updatedmodel.sav")

# Define the questions along with their options and points
questions = [
    {
        'question': 'Little interest or pleasure in doing things',
        'options': [
            {'text': 'Not at all', 'points': 0},
            {'text': 'Several days', 'points': 1},
            {'text': 'More than half the days', 'points': 2},
            {'text': 'Nearly every day', 'points': 3}
        ]
    },
     {
        'question': 'Feeling down, depressed, or hopeless',
        'options': [
            {'text': 'Not at all', 'points': 0},
            {'text': 'Several days', 'points': 1},
            {'text': 'More than half the days', 'points': 2},
            {'text': 'Nearly every day', 'points': 3}
        ]
    },
     {
        'question': 'Trouble falling or staying asleep, or sleeping too much',
        'options': [
            {'text': 'Not at all', 'points': 0},
            {'text': 'Several days', 'points': 1},
            {'text': 'More than half the days', 'points': 2},
            {'text': 'Nearly every day', 'points': 3}
        ]
    },
     {
        'question': 'Feeling tired or having little energy',
        'options': [
            {'text': 'Not at all', 'points': 0},
            {'text': 'Several days', 'points': 1},
            {'text': 'More than half the days', 'points': 2},
            {'text': 'Nearly every day', 'points': 3}
        ]
    },
     {
        'question': 'Poor appetite or overeating',
        'options': [
            {'text': 'Not at all', 'points': 0},
            {'text': 'Several days', 'points': 1},
            {'text': 'More than half the days', 'points': 2},
            {'text': 'Nearly every day', 'points': 3}
        ]
    },
     {
        'question': 'Feeling bad about yourself or that you are a failure or have let yourself or your family down',
        'options': [
            {'text': 'Not at all', 'points': 0},
            {'text': 'Several days', 'points': 1},
            {'text': 'More than half the days', 'points': 2},
            {'text': 'Nearly every day', 'points': 3}
        ]
    },
     {
        'question': 'Trouble concentrating on things, such as reading the newspaper or watching television',
        'options': [
            {'text': 'Not at all', 'points': 0},
            {'text': 'Several days', 'points': 1},
            {'text': 'More than half the days', 'points': 2},
            {'text': 'Nearly every day', 'points': 3}
        ]
    },
     {
        'question': 'Moving or speaking so slowly that other people could have noticed. Or the opposite being so fidgety or restless that you have been moving around a lot more than usual',
        'options': [
            {'text': 'Not at all', 'points': 0},
            {'text': 'Several days', 'points': 1},
            {'text': 'More than half the days', 'points': 2},
            {'text': 'Nearly every day', 'points': 3}
        ]
    },
     {
        'question': 'Thoughts that you would be better off dead, or of hurting yourself',
        'options': [
            {'text': 'Not at all', 'points': 0},
            {'text': 'Several days', 'points': 1},
            {'text': 'More than half the days', 'points': 2},
            {'text': 'Nearly every day', 'points': 3}
        ]
    },
     {
        'question': 'Feeling nervous, anxious, or on edge',
        'options': [
            {'text': 'Not at all', 'points': 0},
            {'text': 'Several days', 'points': 1},
            {'text': 'More than half the days', 'points': 2},
            {'text': 'Nearly every day', 'points': 3}
        ]
    },
     {
        'question': 'Not being able to stop or control worrying',
        'options': [
            {'text': 'Not at all', 'points': 0},
            {'text': 'Several days', 'points': 1},
            {'text': 'More than half the days', 'points': 2},
            {'text': 'Nearly every day', 'points': 3}
        ]
    },
     {
        'question': 'Worrying too much about different things',
        'options': [
            {'text': 'Not at all', 'points': 0},
            {'text': 'Several days', 'points': 1},
            {'text': 'More than half the days', 'points': 2},
            {'text': 'Nearly every day', 'points': 3}
        ]
    },
     {
        'question': 'Trouble relaxing',
        'options': [
            {'text': 'Not at all', 'points': 0},
            {'text': 'Several days', 'points': 1},
            {'text': 'More than half the days', 'points': 2},
            {'text': 'Nearly every day', 'points': 3}
        ]
    },
     {
        'question': 'Being so restless that it is hard to sit still',
        'options': [
            {'text': 'Not at all', 'points': 0},
            {'text': 'Several days', 'points': 1},
            {'text': 'More than half the days', 'points': 2},
            {'text': 'Nearly every day', 'points': 3}
        ]
    },
     {
        'question': 'Becoming easily annoyed or irritable',
        'options': [
            {'text': 'Not at all', 'points': 0},
            {'text': 'Several days', 'points': 1},
            {'text': 'More than half the days', 'points': 2},
            {'text': 'Nearly every day', 'points': 3}
        ]
    },
     {
        'question': 'Feeling afraid, as if something awful might happen',
        'options': [
            {'text': 'Not at all', 'points': 0},
            {'text': 'Several days', 'points': 1},
            {'text': 'More than half the days', 'points': 2},
            {'text': 'Nearly every day', 'points': 3}
        ]
    }
    # Add more questions in the same format here
]


prediction_labels = {
    0: "Depressed",
    1: "Non-Depressed",
    "default": "No depression"
}

@app.route('/', methods=['GET', 'POST'])
def index():
    if request.method == 'POST':
        # Calculate score based on selected options
        score = 0
        for i, question in enumerate(questions):
            selected_option_index = int(request.form[f'answer{i}'])
            score += question['options'][selected_option_index]['points']

        # Calculate depression level based on the score
        depression_level = ""
        if score >= 20:
            depression_level = "Severe depression"
        elif score >= 15:
            depression_level = "Moderately severe depression"
        elif score >= 10:
            depression_level = "Moderate depression"
        elif score >= 5:
            depression_level = "Mild depression"
        else:
            depression_level = "No depression"

        # Reshape the input data to match the expected shape
        prediction = model.predict(np.array([score] * 16).reshape(1, -1))

        # Get the prediction label
        prediction_label = prediction_labels.get(prediction[0], prediction_labels["default"])

        # Render the score along with the depression level and prediction
        return render_template('score.html', score=score, depression_level=depression_level, prediction=prediction_label)
    else:
        return render_template('index.html', questions=questions)


@app.route('/submit', methods=['POST'])
def submit():
    # Process the form submission and return the result
    return "Form submitted successfully!"
# Route for the home page
@app.route('/home')
def home():
    return render_template('home.html')


@app.route('/mystory')
def mystory():
    return render_template('mystory.html')
# Function to perform face detection
# Define the blueprint for face detection
# Define the blueprint for face detection
@app.route('/introvert_page', methods=['GET'])
@app.route('/questions', methods=['GET'])
def get_questions():
    return jsonify({'questions': introvert_questions})

@app.route('/contactus')
def contact_us():
    return render_template('contactus.html')

@app.route('/introvert')
def introvert_questionnaire():
    return render_template('introvert.html', questions=introvert_questions)

@app.route('/score1', methods=['POST'])
def introvert_extrovert_score():
    # Process the form submission and calculate the introvert score
    responses = request.form
    agree_count = 0
    disagree_count = 0

    for key, value in responses.items():
        if value == 'agree':
            agree_count += 1
        elif value == 'disagree':
            disagree_count += 1

    # Determine the result based on the introvert score
    if agree_count > disagree_count:
        result = "Introverted"
    elif agree_count < disagree_count:
        result = "Extroverted"
    else:
        result = "Ambivert"

    # Render the score1.html template with the result
    return render_template('score1.html', result=result)
app.register_blueprint(introvert_bp)
app.register_blueprint(facedetection_bp)
# Register the facedetection blueprint

if __name__ == '__main__':
    app.run(debug=True)

