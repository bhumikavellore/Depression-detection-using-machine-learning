from flask import Blueprint, render_template, Response
from keras.models import load_model
from keras.preprocessing.image import img_to_array
import cv2
import numpy as np

# Define the blueprint for face detection
facedetection_bp = Blueprint('facedetection', __name__)

# Load the pre-trained face classifier and emotion detection model
face_classifier = cv2.CascadeClassifier(r"C:\Users\Hi\Downloads\Emotion_Detection_CNN-main\Emotion_Detection_CNN-main\haarcascade_frontalface_default.xml")
emotion_classifier = load_model(r"C:\Users\Hi\Downloads\Emotion_Detection_CNN-main\Emotion_Detection_CNN-main\model.h5")
emotion_labels = ['Not Depressed', 'Not Depressed', 'Not Depressed', 'Not Depressed', 'Depressed', 'Depressed', 'Not Depressed']

# Function to perform face detection and emotion recognition
def detect_emotion(frame):
    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
    faces = face_classifier.detectMultiScale(gray)

    for (x, y, w, h) in faces:
        roi_gray = gray[y:y+h, x:x+w]
        roi_gray = cv2.resize(roi_gray, (48, 48), interpolation=cv2.INTER_AREA)

        if np.sum([roi_gray]) != 0:
            roi = roi_gray.astype('float') / 255.0
            roi = img_to_array(roi)
            roi = np.expand_dims(roi, axis=0)

            prediction = emotion_classifier.predict(roi)[0]
            label_index = prediction.argmax()
            label = emotion_labels[label_index]
            cv2.putText(frame, label, (x, y), cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 255, 0), 2)
            cv2.rectangle(frame, (x, y), (x+w, y+h), (0, 255, 255), 2)

    return frame

# Function to generate video frames with emotion detection
def generate_frames():
    cap = cv2.VideoCapture(0)
    while True:
        ret, frame = cap.read()
        if not ret:
            break

        # Perform emotion detection on the frame
        frame = detect_emotion(frame)

        # Encode the frame as JPEG
        ret, buffer = cv2.imencode('.jpg', frame)
        frame = buffer.tobytes()

        # Yield the frame in a Flask response
        yield (b'--frame\r\n'
               b'Content-Type: image/jpeg\r\n\r\n' + frame + b'\r\n')

    cap.release()

# Route for face detection with emotion recognition
@facedetection_bp.route('/detect_face')
def detect_face():
    # Return a streaming response with the emotion detection frames
    return Response(generate_frames(), mimetype='multipart/x-mixed-replace; boundary=frame')
