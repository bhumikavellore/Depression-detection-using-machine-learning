from flask import Flask, request, jsonify, render_template
from flask import Blueprint, render_template
from flask import render_template, request


app = Flask(__name__)
introvert_bp = Blueprint('introvert', __name__)

introvert_questions = [
    {"number": 1,"question": "Meeting new people makes me feel drained.", "options": ["agree", "disagree"]},
    {"number": 2,"question": "I prefer to listen rather than talk when meeting new people.", "options": ["agree", "disagree"]},
    {"number": 3,"question": "I am uncomfortable when around loud people.", "options": ["agree", "disagree"]},
    {"number": 4,"question": "I often can't think of anything interesting to say in conversation.", "options": ["agree", "disagree"]},
    {"number": 5,"question": "In busy environments such as shopping malls, I tire very quickly.", "options": ["agree", "disagree"]},
    {"number": 6,"question": "When I speak, I am often ignored by people.", "options": ["agree", "disagree"]},
    {"number": 7,"question": "I enjoy expressing myself in writing because I can be precise.", "options": ["agree", "disagree"]},
    {"number": 8,"question": "I feel good when I spend time alone in nature.", "options": ["agree", "disagree"]},
    {"number": 9,"question": "I am comfortable with silence when among friends.", "options": ["agree", "disagree"]},
    {"number": 10,"question": "Bright lights in a room give me a headache and drain my energy.", "options": ["agree", "disagree"]},
    {"number": 11,"question": "I don't like people, so I avoid them.", "options": ["agree", "disagree"]},
    {"number": 12,"question": "I am most productive when working or studying alone.", "options": ["agree", "disagree"]},
    {"number": 13,"question": "My favorite hobbies are things I can do alone.", "options": ["agree", "disagree"]},
    {"number": 14,"question": "I dread introducing myself to a group of people.", "options": ["agree", "disagree"]},
    {"number": 15,"question": "I consider myself to be outgoing.", "options": ["agree", "disagree"]},
    {"number": 16,"question": "I feel more energized after spending time alone rather than being in a group setting.", "options": ["agree", "disagree"]}
]

@introvert_bp.route('/introvert')
def introvert_questionnaire():
    return render_template('introvert.html', questions=introvert_questions)

@introvert_bp.route('/score1', methods=['POST'])
def introvert_extrovert_score():
    # Process the form submission and calculate the introvert score
    responses = request.form
    agree_count = 0
    disagree_count = 0

    for key, value in responses.items():
        if value == 'agree':
            agree_count += 1
        elif value == 'disagree':
            disagree_count += 1

    # Determine the result based on the introvert score
    if agree_count > disagree_count:
        result = "Introverted"
    elif agree_count < disagree_count:
        result = "Extroverted"
    else:
        result = "Ambivert"

    # Render the score1.html template with the result
    return render_template('score1.html', result=result)
if __name__ == '__main__':
    app.run(debug=True)
